#include "sttt.h"
#include<iostream>
using namespace std;
void Time::SetTime(int h,int m,int s)
{
    hour=h;
    minute=m;
    second=s;
}
Time::Time(int h,int m,int s)
{
    hour=h;
    minute=m;
    second=s;
}
Time::Time(int s)
{
    int m,h;
    m=s/60;
    s=s%60;
    h=m/60;
    m=m%60;
    hour=h;
    minute=m;
    second=s;
}
void Time::print_12()
{
    if(hour>12)
    {
       cout.fill('0');
       cout.width(2);
       cout<<hour-12<<":";
       cout.fill('0');
       cout.width(2);
       cout<<minute<<":";
       cout.fill('0');
       cout.width(2);
       cout<<second<<" PM";
    }
    else
    {
       cout.fill('0');
       cout.width(2);
       cout<<hour<<":";
       cout.fill('0');
       cout.width(2);
       cout<<minute<<":";
       cout.fill('0');
       cout.width(2);
       cout<<second<<" AM";
    }

}
void Time::print_24()
{
       cout.fill('0');
       cout.width(2);
       cout<<hour<<":";
       cout.fill('0');
       cout.width(2);
       cout<<minute<<":";
       cout.fill('0');
       cout.width(2);
       cout<<second;
}
Time Time::Add(Time &p)
{
    Time a;
    int hhour,mminute,ssecond;
    a.hour=hour;
    a.minute=minute;
    a.second=second;
    int s=p.SecCalc()+a.SecCalc();
    hhour=s/3600;
    mminute=(s-hhour*3600)/60;
    ssecond=(s-hhour*3600-mminute*60);
    a.hour=hhour;
    a.minute=mminute;
    a.second=ssecond;
    return a;
}
Time Time::Sub(Time &p)
{
    Time a;
    a.hour=hour;
    a.minute=minute;
    a.second=second;
    int hhour,mminute,ssecond;
    int s=p.SecCalc()-a.SecCalc();
    if(s<0){s=s*(-1);}
    hhour=s/3600;
    mminute=(s-hhour*3600)/60;
    ssecond=(s-hhour*3600-mminute*60);
    a.hour=hhour;
    a.minute=mminute;
    a.second=ssecond;
    return a;
}
