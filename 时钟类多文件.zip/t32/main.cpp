#include <iostream>
#include"sttt.h"
using namespace std;

int main()
{
    Time t1(2,34),t2,t3(3723);
     t2.SetTime(13,23,34);
     cout<<"t2:";
     t2.print_12();
     cout<<endl<<"t2:";
     t2.print_24();
     cout<<"\nt1+t2:";
      t1.Add(t2).print_24();
      cout<<"\nt2-t1:";
      t2.Sub(t1).print_24();
      cout<<endl<<"t3:";
      t3.print_24();
    return 0;
}
