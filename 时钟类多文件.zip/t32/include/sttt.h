#ifndef STTT_H
#define STTT_H


class Time
{
private:
  int hour,minute,second;
public:
  Time(int h,int m,int s=0);
  Time(int s=0);
  int SecCalc(){return(hour*60+minute)*60+second;  }
  void SetTime(int h=0,int m=0, int s=0);
  void print_12();
  void print_24();
  Time Add(Time &T);
  Time Sub(Time &T);
};
#endif // STTT_H
