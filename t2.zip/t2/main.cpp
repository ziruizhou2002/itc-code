#include <iostream>
#include"String.h"
#include<string.h>
using namespace std;

int main()
{
    String s1,s2("hello");
    String s3(s2);
    return 0;
}
