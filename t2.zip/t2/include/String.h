#ifndef STRING_H
#define STRING_H
#include<cstddef>

class String
{
public:
    String(const char *str=NULL);
    String(const String &r);
    ~String();
private:
    char *mydata;
};

#endif // STRING_H
